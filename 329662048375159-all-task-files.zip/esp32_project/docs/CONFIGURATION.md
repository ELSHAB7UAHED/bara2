# إعدادات المشروع المتقدمة

## متغيرات النظام

### إعدادات WiFi
```cpp
// في ملف src/main.ino - تحديث هذه القيم
const char* ssid = "YOUR_WIFI_SSID";
const char* password = "YOUR_WIFI_PASSWORD";

// للاتصال بدوال WiFi آخرى (optional)
WiFiMulti wifiMulti;

// إضافة عدة شبكات
wifiMulti.addAP("network1", "password1");
wifiMulti.addAP("network2", "password2");
```

### إعدادات الخادم
```cpp
// المنافذ
#define WEB_SERVER_PORT 80
#define TELEMETRY_PORT 8080

// HTTP Server
WebServer server(WEB_SERVER_PORT);

// API Endpoints
void setup_endpoints() {
    server.on("/", handleRoot);
    server.on("/api/status", handleStatus);
    server.on("/api/control", handleControl);
    server.on("/api/config", handleConfig);
    server.onNotFound(handleNotFound);
}
```

### إعدادات الشبكة
```cpp
// Static IP (optional)
IPAddress localIP(192, 168, 1, 100);
IPAddress gateway(192, 168, 1, 1);
IPAddress subnet(255, 255, 255, 0);
IPAddress dns1(8, 8, 8, 8);
IPAddress dns2(8, 8, 4, 4);
```

### إعدادات الـ Pins
```cpp
// ESP32 DevKit Pins
#define LED_PIN 2
#define BUTTON_PIN 0
#define BUZZER_PIN 4
#define RELAY_PIN 5

// Analog Pins
#define SENSOR_PIN A0
#define VOLTAGE_PIN A3

// I2C Pins (default)
#define SDA_PIN 21
#define SCL_PIN 22

// SPI Pins
#define MISO_PIN 19
#define MOSI_PIN 23
#define SCK_PIN 18
#define CS_PIN 5
```

### إعدادات النظام
```cpp
// Timer Settings
#define BLINK_INTERVAL 1000
#define BUTTON_DEBOUNCE 50
#define WIFI_TIMEOUT 10000

// Memory Settings
#define HEAP_MONITOR_INTERVAL 30000
#define MAX_RETRY_CONNECTIONS 3
```

## متغيرات bara.cpp المخصصة

عند تحديث المشروع بمحتوى bara.cpp، ستحتاج لتحديث:

### المكتبات المطلوبة
```cpp
// في platformio.ini - أضف حسب bara.cpp
lib_deps = 
    # Network libraries
    WiFi@^1.0
    WebServer@^1.0
    HTTPClient@^1.0
    WiFiMulti@^1.0
    
    # Sensors & I/O
    Wire@^1.0
    SPI@^1.0
    HX711@^0.7.4
    DHT@^1.4.3
    BME280@^2.2.2
    
    # LED & Display
    FastLED@^3.6.0
    Adafruit_GFX@^1.11.5
    Adafruit_SSD1306@^2.5.7
    
    # Communication
    SerialWiFiTerminal@^1.0.0
    AsyncTCP@^1.1.1
```

### إعدادات المكونات
```cpp
// في ملف src/main.ino
// أضف متغيرات bara.cpp هنا

// For LED strip
#define LED_COUNT 30
#define LED_PIN 2
#define BRIGHTNESS 100

// For sensors
#define SENSOR_TYPE_DHT
#define DHT_PIN 4
#define DHT_TYPE DHT22

// For relays
#define RELAY_COUNT 4
int relayPins[RELAY_COUNT] = {5, 6, 7, 8};

// For communication
#define BAUD_RATE 115200
#define SERIAL_TIMEOUT 1000
```

## متغيرات التكوين المتقدمة

### إدارة الطاقة
```cpp
// Power Management
#define SLEEP_TIME 30000  // 30 seconds
#define DEEP_SLEEP true
#define WAKE_UP_PIN 0

void enterDeepSleep() {
    Serial.println("Entering deep sleep...");
    esp_deep_sleep_start();
}
```

### مراقبة النظام
```cpp
// System Monitoring
void printSystemInfo() {
    Serial.println("=== System Information ===");
    Serial.print("Free Heap: ");
    Serial.println(ESP.getFreeHeap());
    Serial.print("Flash Size: ");
    Serial.println(ESP.getFlashChipSize());
    Serial.print("CPU Frequency: ");
    Serial.println(ESP.getCpuFreqMHz());
    Serial.print("Uptime: ");
    Serial.println(millis());
}
```

### WiFi Advanced
```cpp
// Advanced WiFi Settings
void setupWiFi() {
    WiFi.setAutoReconnect(true);
    WiFi.persistent(false);
    
    // Custom MAC address
    uint8_t newMAC[] = {0x02, 0x00, 0x00, 0xF1, 0xF1, 0xF1};
    WiFi.mode(WIFI_OFF);
    WiFi.begin(ssid, password);
    
    while (WiFi.status() != WL_CONNECTED) {
        delay(1000);
        Serial.print(".");
    }
}
```

## إعدادات OTA (Over-The-Air Updates)
```cpp
// OTA Configuration
#include <ArduinoOTA.h>

void setupOTA() {
    ArduinoOTA.onStart([]() {
        Serial.println("OTA Update Starting...");
    });
    ArduinoOTA.onEnd([]() {
        Serial.println("OTA Update Complete");
    });
    ArduinoOTA.begin();
}
```

## متغيرات التحديث التلقائي
```cpp
// Auto Update Settings
#define AUTO_UPDATE_INTERVAL 3600000  // 1 hour
#define FIRMWARE_VERSION "1.0.0"
#define HARDWARE_VERSION "v1.0"

void checkForUpdates() {
    // Check for firmware updates
    if (checkNewVersionAvailable()) {
        downloadAndInstallUpdate();
    }
}
```

---

**تحديث لـ bara.cpp**: قم بإضافة متغيراتbara.cpp الفعلية في هذا الملف