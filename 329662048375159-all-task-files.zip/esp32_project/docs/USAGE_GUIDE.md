# دليل استخدام ESP32 - bara2

## نظرة عامة
هذا الدليل يوضح كيفية رفع المشروع على GitHub وبناء firmware لـ ESP32.

## متطلبات النظام

### البرمجيات المطلوبة
- Python 3.7+
- Git
- PlatformIO Core أو Arduino IDE

### المتطلبات للأجهزة
- ESP32 Development Board
- USB Cable
- ESP32 flashing tools

## خطوات الرفع على GitHub

### 1. إنشاء مستودع GitHub
```bash
# إنشاء مستودع جديد
# الاسم: bara2
# النوع: Public
# لا تضيف README أو gitignore (لدينا بالفعل)
```

### 2. رفع الكود للمستودع
```bash
# في مجلد esp32_project
git init
git add .
git commit -m "Initial ESP32 project setup"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/bara2.git
git push -u origin main
```

### 3. إعداد GitHub Actions
الـ workflow موجود بالفعل في `.github/workflows/build.yml`
- سيقوم ببناء firmware تلقائياً
- سيتم إنشاء releases عند كل push

## البناء والتحميل

### البناء المحلي
```bash
# باستخدام Makefile
cd esp32_project
make build

# باستخدام Python script
cd esp32_project
python scripts/build.py build

# باستخدام PlatformIO
cd esp32_project
pio run
```

### بناء target محدد
```bash
# بناء ESP32 فقط
pio run --environment esp32dev

# بناء ESP32-C3 فقط
pio run --environment esp32-c3

# بناء ESP32-S3 فقط
pio run --environment esp32-s3
```

### رفع البرنامج للـ ESP32
```bash
# رفع مع مراقبة
make upload

# أو فقط رفع
pio run --target upload

# تحميل target محدد
pio run --target upload --environment esp32-c3
```

## مراقبة الـ Serial
```bash
# مراقبة البيانات
pio device monitor

# مراقبة مع baud rate محدد
pio device monitor --baud 115200
```

## إنشاء Release
```bash
# إنشاء release package
make release

# أو باستخدام Python
python scripts/build.py release
```

## خطوات التخصيص

### 1. تحديث WiFi Settings
في ملف `src/main.ino`، قم بتحديث:
```cpp
WiFi.begin("YOUR_WIFI_SSID", "YOUR_WIFI_PASSWORD");
```

### 2. تحديث Pin Definitions
```cpp
#define LED_PIN 2
#define BUTTON_PIN 0
// أضف المزيد حسب الحاجة
```

### 3. إضافة مكتبات
في `platformio.ini`:
```ini
lib_deps = 
    ESPAsyncWebServer@^1.2.3
    ArduinoJson@^6.18.4
```

## تشخيص المشاكل

### مشاكل البناء
```bash
# تنظيف وإعادة بناء
make clean
make build

# أو
pio run --target clean
pio run
```

### مشاكل الفلاش
- تأكد من connected ESP32
- تحقق من port number
- تأكد من board selection

### مراقبة الـ Logs
```bash
# لمراقبة أخطاء GitHub Actions
# اذهب إلى GitHub > Repository > Actions
```

## GitHub Releases

### التلقائية
- يتم إنشاؤها تلقائياً عند كل push لـ main
- تحتوي على firmware binaries
- تشمل release notes

### اليدوية
```bash
# إنشاء release يدوياً من terminal
gh release create v1.0.0 --title "Version 1.0.0" --notes "Initial release"
```

## بنية الملفات
```
esp32_project/
├── src/                    # Source code
│   └── main.ino           # Main Arduino sketch
├── include/               # Header files
├── lib/                   # Custom libraries
├── platformio.ini         # PlatformIO configuration
├── Makefile              # Build automation
├── scripts/
│   └── build.py          # Python build script
├── .github/
│   └── workflows/
│       └── build.yml     # GitHub Actions
├── README.md             # Project documentation
├── .gitignore           # Git ignore rules
└── LICENSE              # MIT License
```

## نصائح مفيدة

1. **اختبر البيئة المحلية أولاً** قبل دفع لـ GitHub
2. **استخدم git tags** للإصدارات المهمة
3. **راجع GitHub Actions logs** عند فشل البناء
4. **احتفظ بنسخ backup** من firmware working
5. **توثيق التغييرات** في releases

## الدعم

للحصول على الدعم:
- فتح issue في GitHub repository
- مراجعة PlatformIO documentation
- مراجعة ESP32 Arduino documentation

---

**تم إنشاؤه بواسطة MiniMax Agent - 2025-11-02**