#!/usr/bin/env python3
"""
ESP32 Project - bara2 Build Script
Python script for automated building and flashing

Author: MiniMax Agent
Date: 2025-11-02
"""

import os
import sys
import subprocess
import shutil
from pathlib import Path
import json
from datetime import datetime

class ESP32Builder:
    def __init__(self, project_dir="esp32_project"):
        self.project_dir = Path(project_dir)
        self.build_dir = self.project_dir / "build"
        self.release_dir = Path("releases")
        
    def run_command(self, cmd, cwd=None):
        """Run shell command and return result"""
        try:
            result = subprocess.run(
                cmd, 
                shell=True, 
                capture_output=True, 
                text=True, 
                cwd=cwd or self.project_dir
            )
            return result.returncode == 0, result.stdout, result.stderr
        except Exception as e:
            return False, "", str(e)
    
    def check_pio(self):
        """Check if PlatformIO is installed"""
        success, stdout, stderr = self.run_command("pio --version")
        if success:
            print(f"✓ PlatformIO found: {stdout.strip()}")
            return True
        else:
            print("❌ PlatformIO not found. Installing...")
            return self.install_pio()
    
    def install_pio(self):
        """Install PlatformIO"""
        print("Installing PlatformIO...")
        success, stdout, stderr = self.run_command("pip install platformio")
        if success:
            print("✓ PlatformIO installed successfully")
            return True
        else:
            print(f"❌ Failed to install PlatformIO: {stderr}")
            return False
    
    def build_target(self, target):
        """Build firmware for specific target"""
        print(f"\n🏗️  Building for {target}...")
        
        success, stdout, stderr = self.run_command(
            f"pio run --environment {target}"
        )
        
        if success:
            print(f"✅ Successfully built {target}")
            return True
        else:
            print(f"❌ Failed to build {target}")
            print(f"Error: {stderr}")
            return False
    
    def build_all(self):
        """Build for all supported targets"""
        targets = ["esp32dev", "esp32-c3", "esp32-s3"]
        results = {}
        
        if not self.check_pio():
            return False
        
        for target in targets:
            results[target] = self.build_target(target)
        
        return all(results.values())
    
    def create_release(self):
        """Create release package with all firmware files"""
        print("\n📦 Creating release package...")
        
        self.release_dir.mkdir(exist_ok=True)
        
        targets = ["esp32dev", "esp32-c3", "esp32-s3"]
        release_files = []
        
        for target in targets:
            bin_file = self.project_dir / f".pio/build/{target}/firmware.bin"
            elf_file = self.project_dir / f".pio/build/{target}/firmware.elf"
            
            if bin_file.exists():
                dest_bin = self.release_dir / f"bara2_{target}.bin"
                shutil.copy2(bin_file, dest_bin)
                release_files.append(dest_bin)
                print(f"✓ Copied {dest_bin}")
            
            if elf_file.exists():
                dest_elf = self.release_dir / f"bara2_{target}.elf"
                shutil.copy2(elf_file, dest_elf)
                release_files.append(dest_elf)
                print(f"✓ Copied {dest_elf}")
        
        # Create release info
        release_info = {
            "project": "bara2",
            "version": datetime.now().strftime("%Y.%m.%d"),
            "build_date": datetime.now().isoformat(),
            "targets": targets,
            "files": [str(f) for f in release_files],
            "size_total": sum(f.stat().st_size for f in release_files)
        }
        
        with open(self.release_dir / "release_info.json", "w") as f:
            json.dump(release_info, f, indent=2)
        
        print(f"\n🎉 Release created in {self.release_dir}")
        print(f"Total files: {len(release_files)}")
        print(f"Total size: {release_info['size_total'] / 1024:.1f} KB")
        
        return True
    
    def flash_device(self, target="esp32dev"):
        """Flash firmware to connected device"""
        print(f"\n⚡ Flashing to {target}...")
        
        # First try to upload
        success, stdout, stderr = self.run_command(
            f"pio run --target upload --environment {target}"
        )
        
        if success:
            print(f"✅ Successfully flashed {target}")
            
            # Start monitor
            print("📡 Starting serial monitor...")
            self.run_command("pio device monitor")
            
            return True
        else:
            print(f"❌ Failed to flash {target}")
            print(f"Error: {stderr}")
            return False
    
    def clean_build(self):
        """Clean build artifacts"""
        print("\n🧹 Cleaning build artifacts...")
        success, stdout, stderr = self.run_command("pio run --target clean")
        
        if success:
            print("✓ Build artifacts cleaned")
            return True
        else:
            print(f"❌ Failed to clean: {stderr}")
            return False
    
    def show_info(self):
        """Show project information"""
        print("\n📋 ESP32 Project - bara2 Information")
        print("=" * 40)
        print(f"Project Directory: {self.project_dir.absolute()}")
        print(f"Build System: PlatformIO")
        print(f"Supported Targets:")
        print("  - ESP32 DevKit (esp32dev)")
        print("  - ESP32-C3 (esp32-c3)")
        print("  - ESP32-S3 (esp32-s3)")
        print()
        print("Commands:")
        print("  python build.py build      # Build all targets")
        print("  python build.py release    # Create release package")
        print("  python build.py flash      # Flash to device")
        print("  python build.py clean      # Clean build artifacts")
        print("  python build.py info       # Show this information")

def main():
    if len(sys.argv) < 2:
        builder = ESP32Builder()
        builder.show_info()
        sys.exit(0)
    
    command = sys.argv[1].lower()
    builder = ESP32Builder()
    
    if command == "build":
        success = builder.build_all()
        if success:
            print("\n🎉 All targets built successfully!")
            sys.exit(0)
        else:
            print("\n💥 Some builds failed!")
            sys.exit(1)
    
    elif command == "release":
        success = builder.build_all() and builder.create_release()
        if success:
            print("\n🎉 Release created successfully!")
            sys.exit(0)
        else:
            print("\n💥 Release creation failed!")
            sys.exit(1)
    
    elif command == "flash":
        target = sys.argv[2] if len(sys.argv) > 2 else "esp32dev"
        success = builder.flash_device(target)
        if not success:
            sys.exit(1)
    
    elif command == "clean":
        success = builder.clean_build()
        if not success:
            sys.exit(1)
    
    elif command == "info":
        builder.show_info()
    
    else:
        print(f"Unknown command: {command}")
        builder.show_info()
        sys.exit(1)

if __name__ == "__main__":
    main()