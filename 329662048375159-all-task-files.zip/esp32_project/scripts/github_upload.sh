#!/bin/bash

# ESP32 Project - bara2 GitHub Upload Script
# Created by MiniMax Agent
# Date: 2025-11-02

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
PROJECT_NAME="bara2"
PROJECT_DIR="esp32_project"
REPO_URL=""
USERNAME=""

echo -e "${BLUE}"
echo "================================================"
echo "    ESP32 Project - bara2 GitHub Setup"
echo "================================================"
echo -e "${NC}"

# Check if we're in the right directory
if [ ! -f "platformio.ini" ]; then
    echo -e "${RED}❌ ملف platformio.ini غير موجود في المجلد الحالي${NC}"
    echo "قم بتشغيل هذا السكريبت من مجلد esp32_project"
    exit 1
fi

# Function to check prerequisites
check_prerequisites() {
    echo -e "${YELLOW}🔍 Checking prerequisites...${NC}"
    
    # Check git
    if ! command -v git &> /dev/null; then
        echo -e "${RED}❌ Git is not installed${NC}"
        echo "Install Git: https://git-scm.com/"
        exit 1
    fi
    
    # Check if git is configured
    if ! git config user.name &> /dev/null; then
        echo -e "${RED}❌ Git is not configured${NC}"
        echo "Configure git:"
        echo "  git config --global user.name 'Your Name'"
        echo "  git config --global user.email 'your.email@example.com'"
        exit 1
    fi
    
    echo -e "${GREEN}✅ Prerequisites checked successfully${NC}"
}

# Function to get GitHub repository URL
get_repo_info() {
    echo -e "${YELLOW}📝 Enter GitHub repository information:${NC}"
    
    echo -n "GitHub Username: "
    read USERNAME
    
    echo -n "Repository name (bara2): "
    read REPO_NAME
    
    if [ -z "$REPO_NAME" ]; then
        REPO_NAME="$PROJECT_NAME"
    fi
    
    REPO_URL="https://github.com/$USERNAME/$REPO_NAME.git"
    
    echo -e "${BLUE}Repository URL: $REPO_URL${NC}"
}

# Function to update project info
update_project_info() {
    echo -e "${YELLOW}🔄 Updating project information...${NC}"
    
    # Update README.md with actual username
    sed -i "s/USERNAME/$USERNAME/g" README.md
    
    # Make scripts executable
    chmod +x scripts/build.py
    chmod +x scripts/github_upload.sh
    
    echo -e "${GREEN}✅ Project information updated${NC}"
}

# Function to initialize git
init_git() {
    echo -e "${YELLOW}🔄 Initializing Git repository...${NC}"
    
    if [ -d ".git" ]; then
        echo "Git repository already exists"
        return
    fi
    
    git init
    git branch -M main
    
    echo -e "${GREEN}✅ Git repository initialized${NC}"
}

# Function to add files to git
add_files() {
    echo -e "${YELLOW}📁 Adding files to Git...${NC}"
    
    git add .
    
    echo -e "${GREEN}✅ Files added to Git${NC}"
}

# Function to create initial commit
create_commit() {
    echo -e "${YELLOW}📝 Creating initial commit...${NC}"
    
    CURRENT_DATE=$(date +"%Y-%m-%d %H:%M:%S")
    git commit -m "Initial ESP32 project setup

- ESP32 Project with PlatformIO build system
- GitHub Actions CI/CD pipeline
- Multi-target support (ESP32, ESP32-C3, ESP32-S3)
- Automatic firmware releases
- Arabic documentation and guides

Created by MiniMax Agent on $CURRENT_DATE"
    
    echo -e "${GREEN}✅ Initial commit created${NC}"
}

# Function to add remote
add_remote() {
    echo -e "${YELLOW}🔗 Adding GitHub remote...${NC}"
    
    # Remove existing remote if exists
    git remote remove origin 2>/dev/null || true
    
    git remote add origin "$REPO_URL"
    
    echo -e "${GREEN}✅ GitHub remote added${NC}"
}

# Function to push to GitHub
push_to_github() {
    echo -e "${YELLOW}⬆️  Pushing to GitHub...${NC}"
    
    if git push -u origin main; then
        echo -e "${GREEN}✅ Successfully pushed to GitHub${NC}"
        echo ""
        echo -e "${GREEN}🎉 Repository created successfully!${NC}"
        echo -e "${BLUE}Repository URL: $REPO_URL${NC}"
        echo -e "${BLUE}GitHub Actions will start building automatically${NC}"
        return 0
    else
        echo -e "${RED}❌ Failed to push to GitHub${NC}"
        echo -e "${YELLOW}Please check:${NC}"
        echo "1. Repository URL is correct"
        echo "2. You have write access to the repository"
        echo "3. Internet connection is working"
        return 1
    fi
}

# Function to show next steps
show_next_steps() {
    echo ""
    echo -e "${GREEN}📋 Next Steps:${NC}"
    echo "1. Visit your repository: $REPO_URL"
    echo "2. Check GitHub Actions tab for build status"
    echo "3. Wait for the first build to complete"
    echo "4. Download firmware from the Releases page"
    echo "5. Flash to your ESP32 device"
    echo ""
    echo -e "${BLUE}Commands for development:${NC}"
    echo "  make build        # Build all targets"
    echo "  make release      # Create release package"
    echo "  make upload       # Flash to device"
    echo "  make monitor      # Start serial monitor"
    echo ""
    echo -e "${YELLOW}To customize WiFi settings, edit: src/main.ino${NC}"
}

# Main function
main() {
    check_prerequisites
    get_repo_info
    update_project_info
    init_git
    add_files
    create_commit
    add_remote
    
    if push_to_github; then
        show_next_steps
        echo ""
        echo -e "${GREEN}🎊 ESP32 bara2 project successfully uploaded to GitHub!${NC}"
    else
        echo ""
        echo -e "${RED}💥 Upload failed. Please try again or check the repository settings.${NC}"
        exit 1
    fi
}

# Run main function
main