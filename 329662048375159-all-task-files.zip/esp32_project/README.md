# bara.cpp - ESP32 WiFi Security Testing Tool

أداة فحص أمان WiFi مخصصة لـ ESP32 مع واجهة ويب عربية وإنجليزية.

**المطور**: أحمد نور أحمد من قنا  
**الهدف**: التعليمي فقط - فحص وتحليل شبكات WiFi  

## ⚠️ تحذير قانوني

هذا المشروع لأغراض تعليمية فقط. تأكد من الحصول على التصريح المناسب قبل اختبار أي شبكة. الوصول غير المصرح به غير قانوني وغير أخلاقي.

## الميزات

- 🔍 **فحص شبكات WiFi**: اكتشاف وتحليل الشبكات المحيطة
- 🌐 **واجهة ويب تفاعلية**: واجهة Matrix-style مع تحديثات فورية
- 📊 **إحصائيات مفصلة**: قوة الإشارة، نوع التشفير، مستوى الأمان
- 📈 **رسوم بيانية**: توزيع قوة الإشارة وأنواع التشفير
- 💾 **تصدير البيانات**: حفظ النتائج بصيغة CSV
- 📱 **دعم متعدد الأجهزة**: ESP32, ESP32-C3, ESP32-S3

## كيفية الاستخدام

### 1. رفع الكود للـ ESP32

```bash
# بناء المشروع
pio run

# رفع البرنامج للـ ESP32
pio run --target upload

# مراقبة Serial Output
pio device monitor
```

### 2. الاتصال بالـ Access Point

- **اسم الشبكة**: `bara`
- **كلمة المرور**: `A7med@Elshab7`
- **عنوان IP**: `192.168.4.1`

### 3. فتح الواجهة

افتح المتصفح واذهب إلى `http://192.168.4.1`

### 4. بدء الفحص

1. اضغط "Start Scan" لفحص الشبكات
2. شاهد النتائج في الجدول المباشر
3. استخدم الرسوم البيانية لتحليل البيانات
4. صدّر النتائج باستخدام "Export Data"

## متطلبات البناء

```bash
# تثبيت PlatformIO Core
pip install platformio

# أو استخدام PlatformIO IDE
# تحميل من: https://platformio.org/install/ide
```

## البناء المحلي

### باستخدام PlatformIO

```bash
# بناء المشروع
pio run

# رفع البرنامج للـ ESP32
pio device monitor
pio run --target upload

# مراقبة Serial Output
pio device monitor
```

### باستخدام Arduino IDE

1. افتح Arduino IDE
2. اختر File > Open
3. اختر ملف `src/main.ino`
4. اختر Board: "ESP32 Dev Module"
5. اضغط Upload

## أنواع ESP32 المدعومة

- **ESP32 DevKit**: أساسي (240MHz, 4MB Flash)
- **ESP32-C3**: إصدار جديد (160MHz, 4MB Flash)
- **ESP32-S3**: أحدث إصدار (240MHz, 4MB Flash)

## GitHub Actions

المشروع يحتوي على GitHub Actions workflow يقوم بـ:
- ✅ بناء firmware لجميع أنواع ESP32
- ✅ إنشاء releases تلقائية
- ✅ رفع binary files كـ GitHub releases
- ✅ إنشاء changelog تلقائي

## Releases

يتم إنشاء releases تلقائية مع كل push إلى main branch.
كل release يحتوي على:
- Firmware binaries (.bin files)
- Changelog
- Release notes

## روابط التحميل

- [GitHub Releases](https://github.com/USERNAME/bara2/releases)
- [PlatformIO Registry](https://platformio.org/) (إذا تم نشره)

## المساهمة

1. Fork المشروع
2. أنشئ feature branch (`git checkout -b feature/amazing-feature`)
3. Commit التغييرات (`git commit -m 'Add some amazing feature'`)
4. Push للـ branch (`git push origin feature/amazing-feature`)
5. افتح Pull Request

## الرخصة

هذا المشروع مرخص تحت [MIT License](LICENSE).

## الدعم

للحصول على الدعم، يرجى فتح issue في GitHub repository.

---

**ملاحظة**: تأكد من تثبيت ESP32 board support في Arduino IDE أو PlatformIO قبل الاستخدام.